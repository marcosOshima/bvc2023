// Check if data exists in local storage for users, properties, and bookings, otherwise fetch from API
// let usersData = JSON.parse(localStorage.getItem("usersData"));
// let propertiesData = JSON.parse(localStorage.getItem("propertiesData"));
// let bookingsData = JSON.parse(localStorage.getItem("bookingsData"));

// if (!usersData || !propertiesData || !bookingsData) {
//   //fetchUsersData();
//   //fetchPropertiesData();
//   //fetchBookingsData();
// }

fetch("/api/users")
  .then((response) => response.json())
  .then((data) => {
    localStorage.setItem("usersData", JSON.stringify(data));
    console.log("Users data saved to local storage:", data);
  })
  .catch((error) => {
    console.error("Error fetching users data:", error);
  });

fetch("/api/properties")
  .then((response) => response.json())
  .then((data) => {
    localStorage.setItem("propertiesData", JSON.stringify(data));
    console.log("Properties data saved to local storage:", data);
  })
  .catch((error) => {
    console.error("Error fetching users data:", error);
  });

fetch("/api/bookings")
  .then((response) => response.json())
  .then((data) => {
    localStorage.setItem("bookingsData", JSON.stringify(data));
    console.log("Bookings data saved to local storage:", data);
  })
  .catch((error) => {
    console.error("Error fetching users data:", error);
  });

$(document).ready(function () {
  // Function to log userData array
  //   function logUserData() {
  //     console.log("Current usersData:", usersData);
  //   }

  // Function to show the create form section and hide the listings section
  function showCreateForm() {
    // Show the create form section
    $("#createFormSection").show();
    // Hide the listings section
    $("#listingsSection").hide();
    // Back to listing section
    $(".backBtn").show();
  }
  // Function to show the index page
  function showIndexPage() {
    $(".index").show();
    $(".login, .signup, .owner, .coworker").hide();
    email = $("#loginEmail").val(""); //Patricia
    password = $("#loginPassword").val(""); //Patricia
  }

  // Show login form when login button is clicked
  $("#login-btn").click(function () {
    $(".index").hide();
    $(".signup, .owner, .coworker").hide();
    $(".login").toggle(); // Toggle the visibility of the login form
  });

  // Show signup form when signup button is clicked
  $("#signup-btn").click(function () {
    $(".index").hide();
    $(".login, .owner, .coworker").hide();
    $(".signup").toggle(); // Toggle the visibility of the signup form
  });

  // Event handler for the back button click
  $(".login .backBtn, .signup .backBtn").click(function () {
    showIndexPage();
  });

  // Function to fill property listings
  function fillListing(container, userId) {
    container.empty();
    propertiesData = JSON.parse(localStorage.getItem("propertiesData"));

    propertiesData.forEach((property) => {
      if (!userId || property.owner === userId) {
        container.append(`<div>${property.address}</div>`);
        // Add more property details to the listing as needed
      }
    });
  }

  // Function to populate property listings for owners
  // Function to populate property listings for owners
  function populateOwnerListings() {
    let ownerListingsContainer = $("#listingsSection");
    ownerListingsContainer.empty();

    // Fetch and parse properties data from local storage
    try {
      const propertiesData = JSON.parse(localStorage.getItem("propertiesData"));
      const currentUser = JSON.parse(localStorage.getItem("currentUser"));

      if (!Array.isArray(propertiesData.properties)) {
        throw new Error("Properties data is not an array");
      }

      propertiesData.properties.forEach((property) => {
        if (property.owner === currentUser.id_user) {
          // Changed ownerId to userId for consistency
          ownerListingsContainer.append(`
                    <div id="ownerListings">
                        <span>${property.address}</span>
                        <br>
                        <button class="editPropertyBtn" data-property-id="${property.id}">Edit</button>
                        <button class="deletePropertyBtn" data-property-id="${property.id}">Delete</button>
                    </div>`);
          // Add more property details to the listing as needed
        }
      });

      // Show the listings section with data added
      $("#listingsSection").show(); // Patricia - display updated listing after addition of new property

      // Hide the create form section
      $("#createFormSection").hide(); // Patricia - hide form of property addition
    } catch (error) {
      console.error("Error:", error.message);
      alert("Error: " + error.message);
    }
  }

  // Function to populate property listings for coworkers
  function populateCoworkerListings() {
    let coworkerListingsContainer = $(".coworkerListings");
    coworkerListingsContainer.empty();

    propertiesData = JSON.parse(localStorage.getItem("propertiesData"));

    propertiesData.properties.forEach((property) => {
      let propertyDetailsHtml = `
        <div id="coworkerListings">
            <p>Address: ${property.address}</p>
            <p>Neighborhood: ${property.neighborhood}</p>
            <p>Area: ${property.area} sq. ft.</p>
            <p>Parking: ${property.parking}</p>
            <p>Public Transportation: ${property.public_transportation}</p>
            <p>Workspace Details:</p>
            <ul>
                ${property.workspace_details
                  .map((workspace) => {
                    return `<li>${workspace.type
                      .split("_")
                      .map(
                        (word) => word.charAt(0).toUpperCase() + word.slice(1)
                      )
                      .join(" ")} - Capacity: ${
                      workspace.seating_capacity
                    }, Price: $${workspace.price}</li>`;
                  })
                  .join("")}
                
            </ul>
            <button class="reservePropertyBtn" data-property-id="${
              property.id
            }">Reserve</button>
        </div>`;
      coworkerListingsContainer.append(propertyDetailsHtml);
    });
  }

  function search() {
    const searchBar = document.getElementById("searchBar").value;

    // Fetch properties data from local storage
    propertiesData = JSON.parse(localStorage.getItem("propertiesData"));

    // Filter properties based on the search input
    let results = propertiesData.filter((property) =>
      property.address.toLowerCase().includes(searchBar.toLowerCase())
    );

    // Display search results
    const searchResultsList = document.getElementById("searchResultsList");
    searchResultsList.innerHTML = "";

    results.forEach((property) => {
      const li = document.createElement("li");
      li.textContent = `${property.address}`;

      // Create the "View More" button and add an onclick event
      const viewMore = document.createElement("button");
      viewMore.textContent = "View More";
      viewMore.onclick = () => fetchProperty(property.id); // Assuming fetchProperty is a function to get more details

      li.appendChild(viewMore);
      searchResultsList.appendChild(li);
    });
  }

  function fetchProperty(propertyId) {
    // Fetch properties data from local storage
    propertiesData = JSON.parse(localStorage.getItem("propertiesData"));

    // Find the property with the given propertyId
    let property = propertiesData.find(
      (property) => property.id === propertyId
    );

    if (property) {
      const viewMoreSection = document.getElementById("viewMore");
      let display = `<h2>${property.address}</h2>`;
      display += `<p>Neighborhood: ${property.neighborhood}</p>`;
      display += `<p>Area: ${property.area}</p>`;
      display += `<p>Parking: ${property.parking}</p>`;
      display += `<p>Public Transportation: ${property.public_transportation}</p>`;

      display += `<h3>Workspace Details</h3>`;
      property.workspace_details.forEach((workspace_details) => {
        display += `<p>${workspace_details.type} - Capacity: ${workspace_details.seating_capacity}, Price: $${workspace_details.price}</p>`;
      });

      viewMoreSection.innerHTML = display;
    } else {
      console.error("Property not found.");
    }
  }

  // Event handler for the reserve button click
  //  $(document).on("click", ".reserveBtn", function () { // comentado por Patricia
  $(document).on("click", ".reservePropertyBtn", function () {
    // Patricia
    const propertiesData = JSON.parse(localStorage.getItem("propertiesData"));

    let propertyId = $(this).data("property-id");
    let property = propertiesData.properties.find(
      (prop) => prop.id === propertyId
    );
    // Set selectedOwnerId to the owner's id of the selected property
    selectedOwnerId = property.owner; // Patricia - this variable will be used to populate array of booking (.reservationForm)
    selectedOwnerProp = property.id; // Patricia - this variable will be used to populate array of booking (.reservationForm)

    if (property) {
      // Populate property details in the reservation section
      $("#propertyName").text(property.address);
      $("#propertyDescription").text(property.Description);

      // Hide the search bar and coworker listing
      $(".searchBar, .coworkerListings").hide();

      // Show the reservation section
      $("#reservation").show();
    }
  });

  //Patricia - begin
  // Function to handle both cancel and back buttons of Booking
  function handleCancelBackButtons_Booking() {
    // Show the search bar and coworker listing
    $(".searchBar, .coworkerListings").show();

    // Hide the reservation section
    $("#reservation").hide();
  }

  // Bind the function to both buttons
  $("#cancelReservationBtn, #backBtnBook").click(
    handleCancelBackButtons_Booking
  );
  // Patricia - end

  // Event handler for the reservation form submission
  $("#reservationForm").submit(function (e) {
    e.preventDefault();
    // Logic to handle reservation submission goes here
    //Patricia - begin
    //Variable to populate array of co-worker bookings - Patricia

    const currentUser = JSON.parse(localStorage.getItem("currentUser"));
    const bookingsData = JSON.parse(localStorage.getItem("bookingsData"));

    var newBooking = {
      id_user: currentUser.id_user,
      id_owner: selectedOwnerId,
      id_property: selectedOwnerProp,
      date: $("#reservationDate").val(),
      start_time: $("#startTime").val(),
      end_time: $("#endTime").val(),
    };

    bookingsData.bookings.push(newBooking);
    console.log(bookingsData.bookings);
    $("#ownerContact").html(`
            <h2><strong> To book a space, please contact directly the owner through: </strong></h2>
            <p><strong>Owner: ${currentUser.name} </strong></p>
            <p><strong>Phone: ${currentUser.phone}</strong></p>
            <p><strong>Email:</strong> <a href="mailto:${currentUser.email}" style="color: blue; text-decoration: none;">${currentUser.email}</a></p>
        `);

    // Update local storage with the updated coworker bookings
    localStorage.setItem("bookingsData", JSON.stringify(bookingsData));
  });

  $("#loginForm").submit(function (e) {
    e.preventDefault();
    try {
      var email = $("#loginEmail").val();
      var password = $("#loginPassword").val();

      // Fetch user data from local storage
      var usersData = localStorage.getItem("usersData");
      if (!usersData) {
        console.error("Error: Users data not found in local storage");
        alert("Error: Users data not found. Please try again later.");
        return;
      }

      var users = JSON.parse(usersData).users; // Assuming 'usersData' has a 'users' property
      if (!Array.isArray(users)) {
        console.error("Error: Users data is not in the correct format");
        alert(
          "Error: Users data is not in the correct format. Please contact support."
        );
        return;
      }

      // Find the user in the local storage data
      var user = users.find(
        (u) => u.email === email && u.password === password
      );
      if (!user) {
        console.error("Error: Invalid email or password");
        alert("Error: Invalid email or password");
        return;
      }

      console.log("User logged in:", user);
      //Save the user data in local storage
      localStorage.setItem("currentUser", JSON.stringify(user));

      $(".index, .login, .signup").hide();
      if (user.role === "owner") {
        $(".owner").show();
        populateOwnerListings(user.id_user);
      } else if (user.role === "coworker") {
        $(".coworker").show();
        populateCoworkerListings();
      }
    } catch (error) {
      console.error("Error:", error);
      alert("Error: " + error.message);
    }
  });

  // Function to handle signup
  $("#signupForm").submit(function (e) {
    e.preventDefault();
    var newUser = {
      id_user: generateUserId(),
      name: $("#name").val(),
      phone: $("#phone").val(),
      email: $("#email").val(),
      password: $("#password").val(),
      role: $("#role").val(),
    };

    // Fetch user data from local storage
    var users = JSON.parse(localStorage.getItem("users")) || [];
    // Add the new user to the existing users array
    users.push(newUser);
    // Update the user data in local storage
    localStorage.setItem("users", JSON.stringify(users));

    console.log("User signed up:", newUser);
    console.log("Updated userData:", users); // Log updated userData array

    // Clear signup form fields after successful signup
    $("#signupForm")[0].reset();

    console.log("User role:", newUser.role); // Log user's role
    if (newUser.role === "owner") {
      $(".index, .login, .signup, .coworker").hide();
      $(".owner").toggle(); // Toggle the visibility of the owner page

      // Fetch property data from local storage
      var properties = JSON.parse(localStorage.getItem("properties")) || [];
      // Fill the listing with properties owned by the user
      fillListing($(".owner .Listings"), newUser.id_user);
    } else if (newUser.role === "coworker") {
      showIndexPage(); // Hide all pages before showing the coworker page
      $(".coworker").toggle(); // Toggle the visibility of the coworker page

      // Fetch property data from local storage
      var properties = JSON.parse(localStorage.getItem("properties")) || [];
      // Fill the listing with all properties
      fillListing($(".coworker .Listings"));
    }
  });

  // Function to handle logout
  $("#logout-btn").click(function () {
    showIndexPage(); // Show index page when logout button is clicked

    // Clear logged-in user information from local storage
    localStorage.removeItem("currentUser");

    console.log("User logged out");
  });

  // Function to generate a unique user ID
  function generateUserId() {
    return "user_" + Math.floor(Math.random() * 1000);
  }

  // Event handler for the back button click
  $("#backBtn").click(function () {
    $("#createFormSection").hide();
    $("#listingsSection").show();
    $(".backBtn").hide(); // Hide the back button when returning to the listings section

    // Set the availability date field with today's date
    let today = new Date().toISOString().slice(0, 10); // Get today's date in yyyy-mm-dd format
    $("#availability_date").val(today); // Set the value of the availability_date input field
  });

  // Function to toggle visibility of listing section
  function showListingSection() {
    const currentUser = JSON.parse(localStorage.getItem("currentUser"));

    //$("#createFormSection").toggle(); // Toggle visibility of create form section - // commented by Patricia
    $("#listingsSection").toggle(); // Toggle visibility of listings section
    // if ($("#listingsSection").is(":visible")) { // commented by Patricia

    // Populate property listings based on current user role
    if (currentUser && currentUser.role === "owner") {
      populateOwnerListings(currentUser.id_user);
    } else if (currentUser && currentUser.role === "coworker") {
      populateCoworkerListings();
    }
  }
  // }

  // Event handler for the "Create New Listing" button click
  $(".ownerListingNav button").click(function () {
    // Toggle between showing the create form section and the listings section
    if ($("#createFormSection").is(":visible")) {
      // If the create form section is visible, show the listings section
      showListingSection();
    } else {
      // If the create form section is not visible, show the create form section
      showCreateForm();
      clearCreateForm();
    }
  });

  //   $("#createListingBtn").click(function () {
  //     // Call the showCreateForm function
  //     showCreateForm();
  //   });

  // Event handler for edit property button click
  $(document).on("click", ".editPropertyBtn", function () {
    let propertyId = $(this).data("property-id");
    //$("#deleteBtn").data("property-id", propertyId);

    // Retrieve property data from local storage
    const propertiesData = JSON.parse(localStorage.getItem("propertiesData"));
    let property = propertiesData.properties.find(
      (prop) => prop.id === propertyId
    );

    if (property) {
      // Populate the create form with property data
      $("#address").val(property.address);
      $("#neighborhood").val(property.neighborhood);
      $("#area").val(property.area);
      $("#parking").val(property.parking.toLowerCase()); // Convert to lowercase
      $("#public_transportation").val(
        property.public_transportation.toLowerCase()
      ); // Convert to lowercase

      // Populate workspace details
      let workspaceDetails = property.workspace_details;
      $("#workspace_type").val(Object.keys(workspaceDetails)[0]);
      $("#seating_capacity").val(
        workspaceDetails[Object.keys(workspaceDetails)[0]].seating_capacity
      );
      $("#availability_date").val(
        workspaceDetails[Object.keys(workspaceDetails)[0]].availability_date
      );
      $("#lease_term").val(
        workspaceDetails[Object.keys(workspaceDetails)[0]].lease_term
      );
      $("#price").val(workspaceDetails[Object.keys(workspaceDetails)[0]].price);
      //TODO ESTE CAMPO NAO EXISTE
      $("#Description").val(property.Description);

      // Switch to create form section
      showCreateForm();
    }
  });

  // Function to clear the create form fields
  function clearCreateForm() {
    $("#propertyForm")[0].reset(); // Reset the form fields to their default state
  }

  // Function to handle property submission
  $("#propertyForm").submit(function (e) {
    e.preventDefault();

    // Retrieve propertiesData from local storage
    const propertiesData = JSON.parse(localStorage.getItem("propertiesData"));
    const currentUser = JSON.parse(localStorage.getItem("currentUser"));

    // Get form data
    let formData = {
      id: propertiesData.properties.length + 1, // Generate a new unique ID for the property
      address: $("#address").val(),
      neighborhood: $("#neighborhood").val(),
      area: $("#area").val(),
      parking: $("#parking").val(),
      public_transportation: $("#public_transportation").val(),
      owner: currentUser.id_user,
      workspace_details: {
        [$("#workspace_type").val()]: {
          seating_capacity: $("#seating_capacity").val(),
          availability_date: $("#availability_date").val(),
          lease_term: $("#lease_term").val(),
          price: $("#price").val(),
        },
      },
    };

    // Add the new property to the propertiesData array
    propertiesData.properties.push(formData);

    // Update propertiesData in local storage
    localStorage.setItem("propertiesData", JSON.stringify(propertiesData));

    // Log the updated propertiesData array
    console.log("Updated propertiesData:", propertiesData);

    // Clear the form fields
    clearCreateForm();

    // Show the owner's property listings again
    populateOwnerListings(currentUser.id_user);

    // Switch back to the listings section
    // showListingSection(); // Uncomment this line if needed
  });

  // Function to delete a property by ID and refresh the property listings
  function deleteProperty(propertyId) {
    console.log("Deleting property with ID:", propertyId);

    // Retrieve propertiesData from local storage
    const propertiesData = JSON.parse(localStorage.getItem("propertiesData"));
    const currentUser = JSON.parse(localStorage.getItem("currentUser"));

    // Find the index of the property to delete
    let indexToDelete = propertiesData.properties.findIndex(
      (prop) => prop.id === parseInt(propertyId)
    );
    console.log("Index to delete:", indexToDelete);
    if (indexToDelete !== -1) {
      // Remove the property from the propertiesData array
      propertiesData.properties.splice(indexToDelete, 1);
      // Update propertiesData in local storage
      localStorage.setItem("propertiesData", JSON.stringify(propertiesData));
      // Log the updated propertiesData array
      console.log("Property deleted. Updated propertiesData:", propertiesData);
      // Clear the form fields
      clearCreateForm();
      // Show the owner's property listings again
      populateOwnerListings(currentUser.id_user);
      // Switch back to the listings section
      // showListingSection(); // Uncomment this line if needed
    } else {
      console.log("Property not found");
    }
  }

  // Event handler for the delete button click
  $(document).on("click", ".deletePropertyBtn", function (e) {
    e.preventDefault();
    console.log("Delete button clicked");
    let propertyId = $(this).data("property-id");
    console.log("Property ID:", propertyId);
    deleteProperty(propertyId);
  });

  // Populate dropdown menus with property details
  let populateDropdowns = () => {
    let seatsDropdown = $("#seatsDropdown");
    let priceDropdown = $("#priceDropdown");
    let sqftDropdown = $("#sqftDropdown");

    // Retrieve properties data from local storage
    propertiesData = JSON.parse(localStorage.getItem("propertiesData"));

    // console.log('Properties data:', propertiesData); // Log propertiesData to see its actual value

    if (
      !propertiesData ||
      !Array.isArray(propertiesData.properties) ||
      propertiesData.properties.length === 0
    ) {
      console.error("Error: No valid properties data available.");
      alert("Error: No valid properties data available");
      return;
    }

    // Now that we have valid propertiesData, proceed with populating dropdowns
    let seatsSet = new Set();
    let priceSet = new Set();
    let sqftSet = new Set();

    propertiesData.properties.forEach((property) => {
      if (
        property.workspace_details &&
        property.workspace_details.meeting_room &&
        property.workspace_details.meeting_room.seating_capacity
      ) {
        seatsSet.add(property.workspace_details.meeting_room.seating_capacity);
      }
      if (
        property.workspace_details &&
        property.workspace_details.private_office &&
        property.workspace_details.private_office.seating_capacity
      ) {
        seatsSet.add(
          property.workspace_details.private_office.seating_capacity
        );
      }
      if (
        property.workspace_details &&
        property.workspace_details.open_desk &&
        property.workspace_details.open_desk.seating_capacity
      ) {
        seatsSet.add(property.workspace_details.open_desk.seating_capacity);
      }

      if (
        property.workspace_details &&
        property.workspace_details.meeting_room &&
        property.workspace_details.meeting_room.price
      ) {
        priceSet.add(property.workspace_details.meeting_room.price);
      }
      if (
        property.workspace_details &&
        property.workspace_details.private_office &&
        property.workspace_details.private_office.price
      ) {
        priceSet.add(property.workspace_details.private_office.price);
      }
      if (
        property.workspace_details &&
        property.workspace_details.open_desk &&
        property.workspace_details.open_desk.price
      ) {
        priceSet.add(property.workspace_details.open_desk.price);
      }

      sqftSet.add(property.area);
    });

    // Populate dropdowns with unique values
    seatsSet.forEach((value) => {
      seatsDropdown.append(`<option value="${value}">${value}</option>`);
    });

    priceSet.forEach((value) => {
      priceDropdown.append(`<option value="${value}">${value}</option>`);
    });

    sqftSet.forEach((value) => {
      sqftDropdown.append(`<option value="${value}">${value} sq. ft.</option>`);
    });
  };

  // Filter properties based on selected options
  let filterProperties = () => {
    propertiesData = JSON.parse(localStorage.getItem("propertiesData"));

    if (!propertiesData || propertiesData.properties.length === 0) {
      console.error("Error: No properties data available.");
      alert("Error: No properties data available");
      return;
    }

    let filteredProperties = propertiesData.properties.filter((property) => {
      let selectedSeats = $("#seatsDropdown").val();
      let selectedPrice = $("#priceDropdown").val();
      let selectedSqft = $("#sqftDropdown").val();

      return (
        (selectedSeats === "placeholder" ||
          property.workspace_details.meeting_room.seating_capacity ==
            selectedSeats ||
          property.workspace_details.private_office.seating_capacity ==
            selectedSeats ||
          property.workspace_details.open_desk.seating_capacity ==
            selectedSeats) &&
        (selectedPrice === "placeholder" ||
          property.workspace_details.meeting_room.price == selectedPrice ||
          property.workspace_details.private_office.price == selectedPrice ||
          property.workspace_details.open_desk.price == selectedPrice) &&
        (selectedSqft === "placeholder" || property.area == selectedSqft)
      );
    });

    // Display filtered properties (you can customize this according to your needs)
    console.log("Filtered Properties:", filteredProperties);
  };

  populateDropdowns(); // Populate dropdown menus with property details

  $("#searchForm").submit(function (e) {
    e.preventDefault();
    filterProperties(); // Filter properties based on selected options
  });
});
